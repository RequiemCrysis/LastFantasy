#include <Windows.h>
#include <string.h>
#include <conio.h>
#include <stdio.h>
#include <stdlib.h>

#define LEFT 75
#define RIGHT 77
#define UP 72
#define DOWN 80
#define ENTER 13
#define ESC 27

#define DELAY 80

#define col GetStdHandle(STD_OUTPUT_HANDLE)

#define BLACK SetConsoleTextAttribute(col, 0x0000);
#define DARK_BLUE  SetConsoleTextAttribute(col, 0x0001);
#define GREEN  SetConsoleTextAttribute(col, 0x0002);
#define BLUE_GREEN  SetConsoleTextAttribute(col, 0x0003);
#define BLOOD  SetConsoleTextAttribute(col, 0x0004);
#define PURPLE  SetConsoleTextAttribute(col, 0x0005);
#define GOLD  SetConsoleTextAttribute(col, 0x0006);
#define ORIGINAL  SetConsoleTextAttribute(col, 0x0007);
#define GRAY  SetConsoleTextAttribute(col, 0x0008);
#define BLUE  SetConsoleTextAttribute(col, 0x0009);
#define HIGH_GREEN  SetConsoleTextAttribute(col, 0x000a);
#define SKY_BLUE  SetConsoleTextAttribute(col, 0x000b);
#define RED  SetConsoleTextAttribute(col, 0x000c);
#define PLUM  SetConsoleTextAttribute(col, 0x000d);
#define YELLOW  SetConsoleTextAttribute(col, 0x000e);
#define WHITE  SetConsoleTextAttribute(col, 0x000f);

#define WHITE_BLACK  SetConsoleTextAttribute(col, 0x00f0);	//����� ���

char cprint(int place);
void printMap(int x, int y, int pos[2]);
void gotoxy(int x, int y);
int isMovable(int pos1, int pos2);
void intro();
int vselection2(int x, int y, char opt1[], char opt2[]);
void delayedPrint(char str[], int delay, int x, int y);
void title();
void flash(int time, int delay);
void battleMsgBox(char str[]);
void printHP(int x, int y, int hp);
int draw();
int battle();

extern int i;