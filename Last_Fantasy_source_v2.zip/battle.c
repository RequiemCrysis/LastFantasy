#include "header.h"

int hp = 10, enemy_hp = 10;
int atk = 2, enemy_atk = 3;
int magic = 3;
int i;
int input;
int dmg;

int battle(){
	int result;
	while(1){
		result = draw();
		if(result == 1)
			return 1;
		else if(result == 2)
			return 2;
		else
			continue;
	}
}

int draw(){
	WHITE;
	/*
	gotoxy(0, 0);
	printf("HP ");

	for(i = 0; i < enemy_hp; i++){
		WHITE_BLACK;
		putchar(' ');
	}
	WHITE;
	*/
	printHP(0, 0, enemy_hp);

	gotoxy(0, 1);
	puts("BOSS in ROFLCOPTER");
	gotoxy(19, 0);
	puts("      LOLOL");
	gotoxy(19, 1);
	puts("        ^");
	gotoxy(19, 2);
	puts("   -----------|   L");
	gotoxy(19, 3);
	puts("  /   []      |===O");
	gotoxy(19, 4);
	puts(" /   ROFL     |   L");
	gotoxy(19, 5);
	puts("[_____________|");
	gotoxy(19, 6);
	puts("    I    I");
	gotoxy(19, 7);
	puts("   [-ROFL-]");
	/*
	gotoxy(27,10);
	printf("HP ");
	for(i = 0; i < hp; i++){
		WHITE_BLACK;
		putchar(' ');
	}
	WHITE;
	*/
	printHP(27, 10, hp);

	gotoxy(27, 11);
	puts("Light warrior");

	gotoxy(0, 8);
	puts(" ()");
	puts("/|\\");
	puts(" |");
	puts("/ |");


	battleMsgBox("What will Light warrior do?");
	input = vselection2(0, 13, "Attack", "Magic");

	if(input == 1){
		dmg = atk;
	}else if(input == 2){
		dmg = magic;
	}

	battleMsgBox("Light warrior attacked BOSS!");
	Sleep(1000);
	gotoxy(0, 12);
	for(i = 0; i < 40; i++){
		putchar(' ');
	}
	gotoxy(0, 12);
	printf("BOSS Take ");
	printf("%d", dmg);
	puts(" damage!");
	enemy_hp -= dmg;
	printHP(0, 0, enemy_hp);

	Sleep(2000);
	if(enemy_hp <= 0){
		battleMsgBox("Light warrior Win!");
		Sleep(2000);
		return 1;
	}

	battleMsgBox("BOSS attacked Light warrior!");
	Sleep(1000);
	gotoxy(0, 12);
	for(i = 0; i < 40; i++){
		putchar(' ');
	}
	gotoxy(0, 12);
	printf("Light warrior Take ");
	printf("%d", enemy_atk);
	puts(" damage!");
	hp -= enemy_atk;
	printHP(27, 10, hp);
	Sleep(2000);
	if(hp <= 0){
		battleMsgBox("BOSS Win!");
		Sleep(2000);
		return 2;
	}
}

void printHP(int x, int y, int hp){
	gotoxy(x, y);
	WHITE;
	printf("HP ");
	for(i = 0; i < hp; i++){
		WHITE_BLACK;
		putchar(' ');
	}
	for(i = hp; i < 10; i++){
		WHITE;
		putchar(' ');
	}
	WHITE;
}

void battleMsgBox(char str[]){
	WHITE;
	gotoxy(0, 12);
	for(i = 0; i < 40; i++){
		putchar(' ');
	}
	gotoxy(0, 12);
	puts(str);
	WHITE;
}
/*
void main(void){
	system("mode con cols=40 lines=21");

	battle();
	system("pause");
}
*/