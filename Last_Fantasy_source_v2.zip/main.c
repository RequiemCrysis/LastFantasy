//---------------------------------------------------------------------
//Last Fantasy V2
//created by SANGWOOK LEE
//---------------------------------------------------------------------
#include "header.h"


/*
//Ŀ�� ���ֱ�
enum {HIDDEN, SHOW};
void CursorView(char show){
	HANDLE hConsole;
	CONSOLE_CURSOR_INFO ConsoleCursor;

	hConsole = col;

	ConsoleCursor.bVisible = show;
	ConsoleCursor.dwSize = 1;

	SetConsoleCursorInfo(hConsole, &ConsoleCursor);
}
*/
void cursor(char s)
{
	HANDLE hConsole;
	CONSOLE_CURSOR_INFO ConsoleCursor;
	hConsole=GetStdHandle(STD_OUTPUT_HANDLE);
	ConsoleCursor.bVisible=s;
	ConsoleCursor.dwSize=1;
	SetConsoleCursorInfo(hConsole , &ConsoleCursor);
}




int main(){
	
	int STARTING[2] = {17, 2};
	int input;
	int pos[2];
	int result;
	pos[0] = STARTING[0];
	pos[1] = STARTING[1];
	
	//CurserView(HIDDEN);
	cursor(0);
	WHITE;
	title();
	gotoxy(32,6);
	WHITE_BLACK;
	/*
	puts("Start");
	gotoxy(32,7);
	WHITE;
	printf("Exit");
	*/
	input = vselection2(32, 6, "start", "exit");
	WHITE;
	if(input == 2){
		return 0;
	}else if(input == 1){
		intro();
		system("cls");
		
		system("mode con cols=40 lines=21");
		prt:printMap(0, 0, pos);
		Sleep(150);
		while(1){
			if(pos[0] == 12 && pos[1] ==31){
				break;
			}
			//input = getch();
			if(GetAsyncKeyState(VK_UP)){
				if(isMovable(pos[0] - 1, pos[1])){
					pos[0]--;
					goto prt;
				}
			}else if(GetAsyncKeyState(VK_DOWN)){
				if(isMovable(pos[0] + 1, pos[1])){
					pos[0]++;
					goto prt;
				}
			}else if(GetAsyncKeyState(VK_LEFT)){
				if(isMovable(pos[0], pos[1] - 1)){
					pos[1]--;
					goto prt;
				}
			}else if(GetAsyncKeyState(VK_RIGHT)){
				if(isMovable(pos[0], pos[1] + 1)){
					pos[1]++;
					goto prt;
				}
			}
		}
		flash(6, 100);
		result = battle();
		if(result == 2){
			system("cls");
			delayedPrint("The Light warrior Fails...", DELAY, 0, 0);
			delayedPrint("And darkness never end in the world...", DELAY, 0, 1);
			delayedPrint("There will be no more light, no more hope, and...", DELAY, 0, 2);
			delayedPrint("no ", DELAY, 0, 4);
			delayedPrint("OOPARTS", 2*DELAY, 3, 4);
			delayedPrint("...", DELAY, 10, 4);
			delayedPrint("Evil creatures live forever, and only disaster left...", DELAY, 0, 5);
			delayedPrint("Try again and save the world from evil creatures!", DELAY, 0, 7);
			delayedPrint("GAME OVER", DELAY, 16, 8);
			gotoxy(0, 20);
		}else if(result == 1){
			system("cls");
			delayedPrint("The Light warrior killed evil BOSS...", DELAY, 0, 0);
			delayedPrint("and the world replenishes light, hope,", DELAY, 0, 1);
			delayedPrint("and ", DELAY, 0, 2);
			delayedPrint("OOPARTS.", 2*DELAY, 4, 2);
			delayedPrint("There are no more evil creatures", DELAY, 0, 3);
			delayedPrint("and OOPARTS replenish forever.", DELAY, 0, 4);
			Sleep(5000);
			delayedPrint("CREDITS", DELAY, 16, 7);
			delayedPrint("SANG WOOK LEE", DELAY, 12, 8);
			gotoxy(0, 20);
		}

		system("pause");
	}
}