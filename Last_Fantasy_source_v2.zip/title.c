#include "header.h"


/*
 ,^.
  |||
  |||       _T_
  |||   .-.[:|:].-.
  ===_ /\|  "'"  |/
   E]_|\/ \--|-|''''|
   O  `'  '=[:]| A  |
          /""""|  P |
         /"""""`.__.'
        []"/"""\"[]
        | \     / |
        | |     | |
      <\\\)     (///>

*/
/*
const char warrior[13][22] = {
	{' ',',','^','.',},
	{' ',' ','|','|','|',},
	{' ',' ','|','|','|',' ',' ',' ',' ',' ',' ',' ','_','T','_',},
	{' ',' ','|','|','|',' ',' ',' ','.','-','.','[',':','|',':',']','.','-','.',},
	{' ',' ','=','=','=','_',' ','/','\\','|',' ',' ','"','\'','"',' ',' ','|','/',},

}
*/
void title(){
	system("mode con cols=78 lines=21");
	puts(" _____                __        _______               __                     ");
	puts("|     |_.---.-.-----.|  |_     |    ___|.---.-.-----.|  |_.---.-.-----.--.--.");
	puts("|       |  _  |__ --||   _|    |    ___||  _  |     ||   _|  _  |__ --|  |  |");
	puts("|_______|___._|_____||____|    |___|    |___._|__|__||____|___._|_____|___  |");
	puts("                                                                      |_____|");
}


void intro(){
	system("cls");
	delayedPrint("Long Time ago...", DELAY, 0, 0);
	Sleep(250);
	delayedPrint("The world was consumed by evil creatures...", DELAY, 0, 1);
	Sleep(250);
	delayedPrint("There was no light, no hope, and...", DELAY, 0, 2);
	Sleep(500);
	delayedPrint("no ", DELAY, 0, 3);
	Sleep(500);
	delayedPrint("OOPARTS...",2*DELAY, 3, 3);
	Sleep(250);
	delayedPrint("But time passes...", DELAY, 0, 4);
	Sleep(250);
	delayedPrint("The light warriors appeard...", DELAY, 0, 5);
	Sleep(250);
	delayedPrint("Will this warriors save the world?", DELAY, 0, 6);
	Sleep(250);
	delayedPrint("and replenish ", DELAY,0, 7);
	Sleep(500);
	delayedPrint("OOPARTS?", 2*DELAY, 14, 7);
}

int decideClass(){
	
	return 1;
}

int ending(){
	system("cls");
}