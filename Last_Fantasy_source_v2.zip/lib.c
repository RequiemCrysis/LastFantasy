#include "header.h"
int input;
int i, j;
void delayedPrint(char str[], int delay, int x, int y){
	int i=0, len=strlen(str);
	gotoxy(x, y);
	for(i = 0;i < len; i++){

		putc(str[i], stdout);
		
		Sleep(delay);
		
		if(GetAsyncKeyState(VK_ESCAPE)){
			gotoxy(x, y);
			puts(str);
			break;
		}
		
	}

}

void flash(int time, int delay){
	system("cls");
	while(time-- > 0){
		system("color F0");
		Sleep(delay);
		system("color 0F");
		Sleep(delay);
	}
}


void gotoxy(int x, int y){
	COORD p = {x, y};
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), p);
}
/*
	vertical�ϰ� select�� ��Ҹ� �ѷ��ִ� �Լ�
*/
int vselection2(int x, int y, char opt1[], char opt2[]){
	int cursor = 1;
	sel:gotoxy(x, y);
		if(cursor == 1){
			WHITE_BLACK;
		}else{
			WHITE;
		}
		
		puts(opt1);
	
		gotoxy(x, y + 1);
		if(cursor == 2){
			WHITE_BLACK;
		}else{
			WHITE;
		}
		puts(opt2);
	while(1){	
		if(GetAsyncKeyState(VK_DOWN) && cursor == 1){
			cursor++;
			goto sel;
		}else if(GetAsyncKeyState(VK_UP) && cursor == 2){
			cursor--;
			goto sel;
		}else if(GetAsyncKeyState(VK_RETURN)){
			return cursor;
		}
	}
}

void printASCII(int x, int y, char **art, int w, int h){
	for(i = 0; i < h; i++){
		gotoxy(x, y + i);
		for(j = 0; j < w; j++){
			putc(art[i][j], stdout);
		}
	}
}